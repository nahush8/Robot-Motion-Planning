1. Run with input file as a command line argument:

python hw5.py input1.txt

Number of interations required for convergence : 50
Parameters chosen in calculating value iteration: The discount factor is 1. 
The value function of goal vertex is 0, so that convergence occurs.
