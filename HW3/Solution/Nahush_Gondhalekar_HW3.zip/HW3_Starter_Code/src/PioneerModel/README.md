ua_ros_p3dx
===========

A ROS/Gazebo Pioneer 3DX model.

To install:
```
$ cd <catkin_ws>/src
$ git clone https://github.com/SD-Robot-Vision/PioneerModel.git
$ cd ..
$ catkin_make
```
