1. Comments are included in the sp.py file for the description of the algorithm and code.
2. Run the python file with input file as a command line argument, for example
   python sp.py input1.txt
3. Error handling is not done so the input file needs to be in the same format mentioned in the problem.
4. output.txt is created in the same folder with the required output strings.
